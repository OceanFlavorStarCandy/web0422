const games = [
    {
        gimg: "https://oceanflavorstarcandy.github.io/web0422/assets/test0902/package01.jpg",
        gtit: "젤다의 전설 티어스 오브 더 킹덤",
        gdate: "2023.05.12",
        gpri: "74,800",
        gtag: "#MD추천 #오픈월드",
        gage: "https://oceanflavorstarcandy.github.io/web0422/assets/test0902/age12.svg",
        gaget: "12세 이용가"
    },
    {
        gimg: "https://oceanflavorstarcandy.github.io/web0422/assets/test0902/package02.jpg",
        gtit: "슈퍼 마리오브라더스 원더",
        gdate: "2023.10.20",
        gpri: "64,800",
        gtag: "#MD추천 #멀티가능",
        gage: "https://oceanflavorstarcandy.github.io/web0422/assets/test0902/ageAll.svg",
        gaget: "전체 이용가"
    },
    {
        gimg: "https://oceanflavorstarcandy.github.io/web0422/assets/test0902/package03.jpg",
        gtit: "별의 커비 디스커버리",
        gdate: "2022.03.25",
        gpri: "64,800",
        gtag: "#MD추천 #2인협동",
        gage: "https://oceanflavorstarcandy.github.io/web0422/assets/test0902/ageAll.svg",
        gaget: "전체 이용가"
    },
    {
        gimg: "https://oceanflavorstarcandy.github.io/web0422/assets/test0902/package04.jpg",
        gtit: "Pokémon LEGENDS 아르세우스",
        gdate: "2022.01.28",
        gpri: "64,800",
        gtag: "#포켓몬 #오픈월드",
        gage: "https://oceanflavorstarcandy.github.io/web0422/assets/test0902/ageAll.svg",
        gaget: "전체 이용가"
    },
    {
        gimg: "https://oceanflavorstarcandy.github.io/web0422/assets/test0902/package05.jpg",
        gtit: "모여봐요 동물의 숲",
        gdate: "2020.03.20",
        gpri: "64,800",
        gtag: "#유유자적 #섬꾸미기",
        gage: "https://oceanflavorstarcandy.github.io/web0422/assets/test0902/ageAll.svg",
        gaget: "전체 이용가"
    }
];